"""
This is a boilerplate pipeline 'model_output'
generated using Kedro 0.18.14
"""
# Fabrica peronsas model_output nodes
import pandas as pd
import numpy as np
from IPython.display import display

from sklearn.pipeline import Pipeline as SklearnPipeline
import joblib
import logging
from typing import Any, List, Dict, Union, Tuple
import gc

import data_bbog_integration_fabrica_personas.pipelines.raw.nodes as raw
import data_bbog_integration_fabrica_personas.pipelines.intermediate.nodes as intermediate
import data_bbog_integration_fabrica_personas.pipelines.primary.nodes as primary
import data_bbog_integration_fabrica_personas.pipelines.feature.nodes as feature
import data_bbog_integration_fabrica_personas.pipelines.model_selection.nodes as ms


logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

#### Funciones Auxiliares para procesar la data
def prepare_data_primary(
    df: pd.DataFrame,
    info_save_select: Any,  # Dic con artefactos
    params: Dict[str, Any]
) -> pd.DataFrame:
    """
    Prepara los datos para realizar el backtesting y predicciones del modelo.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame original en formato pandas.
    scaler_transform: Any
        Transformador o pipeline de escalado que se aplicará a las variables seleccionadas.
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    pd.DataFrame
        DataFrame procesado hasta raw o primary junto con el scaler respectivo.
    """
    logger.info("Iniciando la preparación de datos para el modelo...")
    # Parámetros importantes
    id_col = params['id']
    target_real = params['variable_apertura']
    target_modelo = params['target']
    if "Scaler" not in info_save_select["modelo_produccion"]:
        if info_save_select["modelo_produccion"]["type"] == "Ensamble":
            nodo_i = info_save_select["modelo_produccion"]['nodos_select'][0]
            logger.info(f"Todos los modelos del Ensamble tienen el mismo procesamiento de datos")
            scaler_transform = info_save_select[nodo_i]["Scaler"]
        else:
            raise ValueError("No identifica el Scaler del modelo...")
    else:
        scaler_transform = info_save_select["modelo_produccion"]["Scaler"]
    try:
        df = df.to_pandas()
        logger.info("f Paso la Data de formato polars a pandas")
    except:
        pass
    try:
        # Validar la existencia de las columnas necesarias
        logger.info("Validando columnas requeridas...")
        paso1 = raw.validar_columnas(df, params)
        logger.info("Validación de columnas completada.")
        hashvalue1 = paso1[id_col]
        if scaler_transform.reindex_OneHotEncoding.shape == (0,1):
            # solo variables continuas
            paso4 = raw.values_to_null(paso1)
        else:
            # Convertir los nombres de las columnas a minúsculas
            logger.info("Convirtiendo nombres de columnas a minúsculas...")
            paso2 = raw.convertir_a_minusculas(paso1, params)
    
            # Estandarizar los strings en el DataFrame
            logger.info("Estandarizando valores de texto...")
            paso3 = raw.standardize_strings(paso2, params)
    
            # Reemplazar ciertos valores por nulos según los parámetros
            logger.info("Reemplazando valores específicos por nulos...")
            paso4 = raw.values_to_null(paso3)
        # Cambiar los tipos de datos según la configuración especificada
        logger.info("Cambiando tipos de datos...")
        paso5 = raw.change_dtypes(paso4, params)

        # Validar que los identificadores únicos y los periodos sean correctos
        logger.info("Validando identificadores únicos y periodos...")
        paso5[id_col] = hashvalue1
        paso6 = raw.validate_unique_id_period_pd(paso5, params)

        ## Filtrar datos según el segmento especificado
    
        # logger.info("Filtrando datos por segmento...")
        # paso7 = interm.filter_data_segment_pd(paso6, params)
        # Filtrar datos relacionados con productos
        # logger.info("Filtrando datos de productos...")
        # paso8 = interm.filter_data_prod_pd(paso6, params)
        ## Aplicar filtro de datos de negocio

        # logger.info("Aplicando filtros de negocio...")
        # paso9 = prim.filter_business_data_pd(paso8, params)
        paso9 = paso6.copy()
    except Exception as e:
        logger.error(f"Error en la preparación de datos desde raw hasta primary: {e}")
        raise
    return paso9,scaler_transform

def prepare_data_model_input(
    paso9: pd.DataFrame,
    hashvalue1,
    feature_selected_list: pd.DataFrame,
    scaler_transform: Any,  # Dic con artefactos
    params: Dict[str, Any]
) -> pd.DataFrame:
    """
    Prepara los datos desde Feature hasta Model.

    Parameters
    ----------
    paso9 : pd.DataFrame
        DataFrame hasta Primary en formato pandas.
    feature_selected_list: pd.DataFrame
        Lista de características seleccionadas para el modelo.
    scaler_transform: Any
        Transformador o pipeline de escalado que se aplicará a las variables seleccionadas.
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    pd.DataFrame
        DataFrame procesado hasta desde Feature hasta model Input.
    """
    try:
        # Calcular nuevas variables necesarias para el modelo
        logger.info("Calculando nuevas variables para el modelo...")
        # paso10 = feature.calculate_new_variables_pd(paso8)
        paso10 = feature.calculate_new_variables_pd(paso9)
    
        # Homologar regiones en los datos
        logger.info("Homologando regiones...")
        paso11 = feature.homologate_region(paso10, params)
    
        # Seleccionar las variables que se utilizarán para el modelo
        logger.info("Seleccionando las características especificadas...")
        list_var = list(feature_selected_list['Feature'])
        #list_var = list(feature_selected_list.columns)
        if params['target'] in list_var:
            list_var.remove(params['target'])
        paso12 = paso11[list_var]
    
        # Aplicar transformación o escalado a los datos seleccionados
        logger.info("Aplicando transformación a las variables seleccionadas...")
        paso13, y = scaler_transform.transform(paso11) # inputes de los datos, hashvalue
        for col in scaler_transform.order_col_all:
            if col not in paso13.columns:
                logger.info(f"La variable: '{col}' no esta en el procesamiento de datos..")
        paso13 = paso13[scaler_transform.order_col_all]
        paso13 = pd.DataFrame(paso13, index=hashvalue1.index)
    
        logger.info("Preparación de datos completada exitosamente.")
    except Exception as e:
        logger.error(f"Error en la preparación de datos desde Feature hasta model_input: {e}")
    return paso13

### Funcion Auxiliar para predecir
def predicciones_data(
    df_inputs: pd.DataFrame,
    info_save_select: Any,  # Dic con artefactos
    params: Dict[str, Any]):
    """
    Realiza predicciones y calcula los deciles basándose en las probabilidades predichas.

    Parameters
    ----------
    df_inputs : pd.DataFrame
        DataFrame de entrada que contiene las características para realizar las predicciones.
    modelo_entrenado : Any
        Modelo ya entrenado que se utilizará para predecir.
    params : Dict[str, Any]
        Diccionario de parámetros que incluye el id y la variable objetivo.

    Returns
    -------
    pd.DataFrame
        Array con las predicciones, las probabilidades y los hashvalue
    """
    # Parámetros
    id_col = params['id']
    type_model = info_save_select['modelo_produccion']['type']
    if id_col in df_inputs:
        logger.info(f"Asegurese que los inputs esten ordenados como se entregaron ...")
        df_inputs = df_inputs.drop(columns=[id_col], axis = 1)

    # inputs asegurando el mismo orden de entrenamiento y testeo
    # Realizar las predicciones
    logger.info("Realizando predicciones con el modelo entrenado...")
    if type_model == "Ensamble":
        logger.info(f"Es un Ensamble")
        lopps = list(range(0,len(info_save_select['modelo_produccion']['nodos_select']),1))
    elif type_model == "Models":
        logger.info(f"Es un Modelo de Models")
        lopps = list(range(0,1,1))
    else:
        raise ValueError("No identifica la llave con la que se optimizo el modelo...")
    ## numero de obs a seleccionar
    if params['n_obs_filter'] <=1:
        limit_ = int(df_inputs.shape[0]*params['n_obs_filter'])
    else:
        limit_ = params['n_obs_filter']
    y_pred,y_proba,results_before = ms.forecast_probs(info_save_select,lopps,df_inputs,limit_, params)

    logger.info(f"Y_true_predict: {y_pred['y_pred'].sum()}. Want Select: {limit_}")
    y_pred = np.array(y_pred['y_pred'])
    y_proba = np.array(y_proba['y_p'])
    y_proba = np.nan_to_num(y_proba, nan=0)
    return y_pred,y_proba

def pre_calificar_base(df: pd.DataFrame,
                  feature_selected_list: pd.DataFrame,
                  info_save_select: Any,
                  parameters: Dict[str, Any]) -> pd.DataFrame:
    """
    Ejecuta todo el procesamiento de datos y retorna un DataFrame procesado junto con la base calificada

    Args:
        input_data: DataFrame de entrada que será procesado.

    Returns:
        DataFrame procesado con nuevas variables calculadas.
    """
    id_col = parameters['id']
    fecha_ejecucion=parameters['fecha_ejecucion']

    logger.info("Iniciando preprocesamiento...")
    paso9,scaler_transform = prepare_data_primary(df,info_save_select,  parameters)
    logger.info(f"Copiando y eliminando la columna {id_col} del dataframe de entrada...")
    hashvalue1 = paso9[id_col]
    paso9 = paso9.drop(columns=[id_col], axis = 1)

    paso13 = prepare_data_model_input(paso9,hashvalue1,feature_selected_list,scaler_transform , parameters)

    # Aplica el orden de los inputs y predice 
    logger.info("Iniciando el proceso de predicciones...")
    y_pred,y_proba = predicciones_data(paso13,info_save_select,parameters)

    base_calificada = pd.DataFrame({
        id_col: np.array(hashvalue1),
        'y_pred': y_pred,
        'y_pred_proba': y_proba
    })
    
    base_calificada = base_calificada.sort_values(by = 'y_pred_proba', ascending = False)
    col_names = base_calificada.columns.tolist()
    base_calificada['periodo'] = fecha_ejecucion
    base_calificada = base_calificada[['periodo']+col_names]
    logger.info(f"Numero de predicciones True {(base_calificada['y_pred']==1).sum()}")
    base_calificada = base_calificada[base_calificada['y_pred']==1] # tengo los params['n_obs_filter'] mas propensos
    logger.info(f"Numero de observaciones con P(x>0) {(base_calificada['y_pred_proba']>0).sum()}")
    base_calificada = base_calificada[base_calificada['y_pred_proba']>0]
    return paso13,base_calificada

def calificar_base(df: pd.DataFrame,
                  feature_selected_list: pd.DataFrame,
                  info_save_select: Any,
                  parameters: Dict[str, Any]) -> pd.DataFrame:
    """
    Ejecuta la base de datos calificada (pronosticos) y la adecua para obtener todos las observaciones mas probables (params['n_obs_filter']).

    Args:
        input_data: DataFrame de entrada que será procesado.

    Returns:
        DataFrame procesado con nuevas variables calculadas.
    """
    paso13,base_calificada = pre_calificar_base(df,feature_selected_list,info_save_select,parameters)

    logger.info(f"Se ha calificado la base con exito'{base_calificada.shape}'...")
    return base_calificada