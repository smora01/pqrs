"""
Nodos de la capa modelo_360
"""
from typing import Dict, List, Any, Tuple
from io import StringIO

import re
from scipy import stats
import pandas as pd
import polars as pl
import numpy as np
import logging
from IPython.display import display

import os
import data_bbog_integration_fabrica_personas.pipelines.feature.nodes as feature
import data_bbog_integration_fabrica_personas.pipelines.backtesting.nodes as backtesting


logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)



# funciones auxiliares:
# Python function that loads a parquet from a path
   
def asignar_categoria(row, parameters):
    """
    Segmenta o estratifica al cliente segun los ingresos brutos mensuales de la variable "vlr_bru_mes"
    
    Parameters
    ----------
    row : pd.DataFrame
        DataFrame original en formato pandas con la columna "vlr_bru_mes"
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    array asociado a la estratificacion de ingreso mensual
    """
    try:
        row = row.to_pandas()
    except:
        pass
    valor = row['vlr_ing_bru_mes']
    valor.index = list(range(row.shape[0]))
    salario = parameters['smmlv']
    try:
        valor = valor.astype(float)
    except (ValueError, TypeError):
        return None
    if valor is None or all(valor.isnull()):
        return None

    result = np.array([4]*valor.shape[0])
    result[valor.index[valor.isnull()].tolist()] = 0
    result[valor.index[valor == None].tolist()] = 0
    result[valor.index[valor <= salario].tolist()] = 1
    
    cond = valor.index[(4*salario) <= valor].tolist()
    cond = cond + valor.index[valor <= (10*salario)].tolist()
    cond = list(set(cond))
    result[cond] = 2
    
    result[valor.index[(valor > (10*salario))].tolist()] = 3
    return result

# primer pipeline
def anexos_modelo_360(params):
    """
    Extrae las variables requeridas dentro del formato de entrega del archivo del modelo 360 
    
    Parameters
    ----------
    inputs_df : pd.DataFrame
        DataFrame original sobre el cual se realizo los pronosticos de la data
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    array asociado a la estratificacion de ingreso mensual
    """
    ruta = params['mes_input']
    ids = params['id']
    if ruta[-3:].lower() == "csv":
        try:
            inputs_df = backtesting.load_csv(ruta)
        except ValueError as e:
            logger.info(e)
            logger.info("No carga archivo csv")
    else:
        try:
            inputs_df = backtesting.load_parquet(ruta)
            try:
                inputs_df = inputs_df.to_pandas()
            except:
                pass
        except ValueError as e:
            logger.info(e)
            logger.info("No carga archivo parquet")

    inputs_df = inputs_df[['periodo',ids, 'vlr_ing_bru_mes','departamento']]
    logger.info(f"Mes insumo de los pronosticos: {inputs_df['periodo'].iloc[0]}")
    inputs_df = feature.homologate_region(inputs_df,params)
    inputs_df['decil_ingreso'] = backtesting.deciles_func(inputs_df['vlr_ing_bru_mes'])
    inputs_df['categoria'] = asignar_categoria(inputs_df, params)
    inputs_df['categoria'] = inputs_df['categoria'].replace(0,None)
    inputs_df = inputs_df[[ids, 'region','decil_ingreso','categoria']]
    logger.info(f"Deciles vinculados al ingreso {inputs_df['decil_ingreso'].unique()}")
    return(inputs_df)

# segun pipeline: Cargar los pronosticos
def cargar_bases(params):
    """
    Carga los pronosticos de los productos de forma individual
    
    Parameters
    ----------
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    pd.DataFrame asociado a los pronosticos de la fabrica
    """
    # parametros
    mes = params['mes_vig']
    corte = params['corte_name_archivo']
    productos = params['productos_carpeta'] 
    ids = params['id']
    logger.info(f"Starting campaign base creation for month: {mes}")
    propension_adq_productos = pd.DataFrame()

    for producto in productos:
        try:
            try:
                ruta = f"s3://data-bbog-dev-sandbox-entity/casos-uso/fabrica-personas/{producto}/08-model_output/base_calificada_nueva_{str(corte)}.parquet"
                logger.info('CARGANDO...')
                logger.info(ruta)
                try:
                    df_temp = backtesting.load_csv(ruta)
                except:
                    df_temp = backtesting.load_parquet(ruta)
                ruta = f"s3://data-bbog-dev-sandbox-entity/casos-uso/fabrica-personas/{producto}/09-backtesting/curva_efec.parquet"
                logger.info('CARGANDO...')
                logger.info(ruta)
                try:
                    curva_efec = backtesting.load_csv(ruta)
                except:
                    curva_efec = backtesting.load_parquet(ruta)
            except:
                ruta = f"s3://data-bbog-dev-sandbox-entity/casos-uso/fabrica-personas/{producto}/08-model_output/base_calificada_nueva_{str(corte)}.csv"
                logger.info('CARGANDO...')
                logger.info(ruta)
                try:
                    df_temp = backtesting.load_csv(ruta)
                except:
                    df_temp = backtesting.load_parquet(ruta)
                ruta = f"s3://data-bbog-dev-sandbox-entity/casos-uso/fabrica-personas/{producto}/09-backtesting/curva_efec.csv"
                logger.info('CARGANDO...')
                logger.info(ruta)
                try:
                    curva_efec = backtesting.load_csv(ruta)
                except:
                    curva_efec = backtesting.load_parquet(ruta)

            # Filter only clients that will open the product
            df_temp = df_temp[df_temp["y_pred"] == 1]
            df_temp = df_temp.sort_values(['y_pred_proba'], ascending=False)
            df_temp.index = range(df_temp.shape[0])
            df_temp.index.name = 'Contactabilidad'
            df_temp["pred_proba_normalized"] = stats.zscore(df_temp["y_pred_proba"])
            logger.info(f"Filtered {len(df_temp)} clients predicted to open {producto}")
            labels = curva_efec['Aceleracion'].unique()
            if len(labels) == 5:
                labels = sorted(labels) # ordenando de menor a mayor
                replacement = ['Muy Bajo','Bajo','Medio','Alto','Muy Alto']
                curva_efec['Aceleracion'] = curva_efec['Aceleracion'].replace(labels,replacement)
                curva_efec = curva_efec.rename(columns = {'pend':producto})
                logger.info(curva_efec)

                df_temp['prob_segment'] = np.nan
                for n in range(0,curva_efec.shape[0]):
                    max_call = curva_efec['N'].iloc[n]
                    min_call = curva_efec['N'].iloc[n-1]
                    if n-1 < 0:
                        min_call = 0
                    df_temp.loc[min_call:max_call,'prob_segment'] = curva_efec['Aceleracion'].iloc[n]
            else:
                logger.info(f"Metodo Diferente al comportamiento del backtesting")                
                # Normalize the pred_proba and then split into 3 segments (Low prob, medium prob, high prob)
                df_temp["prob_segment"] = pd.qcut(
                    df_temp["pred_proba_normalized"],
                    q=5,
                    labels=["Muy Bajo","Bajo", "Medio", "Alto", "Muy Alto"])

            # Select required columns and rename as needed
            df_temp = df_temp[[ids, "pred_proba_normalized", "prob_segment","y_pred_proba"]].copy()
            df_temp["product"] = producto
            df_temp["periodo"] = int(mes)

            # Ordena las columnas
            col_order = ["periodo",ids,"product","pred_proba_normalized", "prob_segment","y_pred_proba"]
            df_temp = df_temp[col_order]
            df_temp = df_temp.rename(columns= {'y_pred_proba':'pred_proba'})
            # Filter by is in alto y muy_alto
            #df_temp = df_temp[df_temp["prob_segment"].isin(["Alto", "Muy Alto"])]
            logger.info(f"Filtered {len(df_temp)} clients in 'Alto' or 'Muy Alto' segments for {producto}")

            # Concat to base_campanas
            propension_adq_productos = pd.concat(
                [propension_adq_productos, df_temp], ignore_index=True)
            logger.info(f"Added {len(df_temp)} rows for {producto} to base_campanas")

            col_order = ["periodo",ids,"product","pred_proba_normalized", "prob_segment","y_pred_proba"]

        except Exception as e:
            logger.info(e)
            logger.error(f"Error processing {producto}: {str(e)}")

    # Rename the DataFrame to include the month
    logger.info(f"propension_adq_productos creation completed. Total rows: {len(propension_adq_productos)}")

    # Display the first few rows of the resulting DataFrame
    logger.info("First few rows of the resulting DataFrame:")
    logger.info("\n" + propension_adq_productos.head().to_string())
    return propension_adq_productos

### Funcion auxiliar al Tercer pipeline 
def optimizando_propension(comparacion,new_columns): 
    """
    Identificar el producto con mayor propension entre los productos detectados
    
    Parameters
    ----------
    comparacion:
        DataFrame numerico asociado al nivel del crecimiento de la efectividad (Muy Alto es 5, Alto es 4, etc...)
    
    new_columns:
        Lista asociada al nombre de los productos 

    Returns
    -------
    pd.DataFrame asociado al producto ordenado de mayor propension a menor propension por persona (fila) y columna (ordenamiento)
    """
    n_maximos = pd.DataFrame()
    comparacion_loop = comparacion.replace(0,np.nan).copy()
    
    for i in range(1,1+len(new_columns),1):
        logger.info(f"Idenficiando la oferta: {i}")
        col_name = f'producto_{i}'
        max_i = comparacion_loop.idxmax(axis=1).to_frame().rename(columns={0:col_name})
        n_maximos = pd.concat([n_maximos,max_i], axis = 1)
        ajuste = pd.get_dummies(max_i).replace([True,False],[0,1])
        order_col = []
        for x, y in zip([col_name+"_"]*len(new_columns), new_columns):
            order_col.append(x + y)
        ajuste = ajuste[order_col]
        ajuste.columns = new_columns
        comparacion_loop = ajuste[new_columns] * comparacion_loop[new_columns]
        comparacion_loop = comparacion_loop.replace(0,np.nan)
    return n_maximos
    
def adjust_format(df_order,df_wide_values,column_name):
    """
    Ordena o formatea el datrame 'df_wide_values' segun el ordenamineto optimo del producto en el dataframe 'df_order' para que tengan el mismo formato. 
    
    Parameters
    ----------
    df_order:
        DataFrame String que contiene en cada columna el producto con mayor propension hacia menor propension por persona o fila

    df_wide_values:
        DataFrame con los datos sin el ordenamiento de 'df_order'
    column_name:
        String asociado al nametag asociado a los valores del dataframe 'df_wide_values'

    Returns
    -------
    pd.DataFrame 'df_wide_values' con la estructura de 'df_order' y la identificacion de columnas seguns 'column_names'
    """
    propension_val = pd.DataFrame(index = df_wide_values.index, columns= df_order.columns).replace(np.nan,3)
    n_maximos = df_order.fillna(np.nan)
    logger.info(f"Iniciando el ordenamiento de {column_name} segun la mejor propension")
    for col in n_maximos:
        for labels in n_maximos[col].unique():
            cond = False
            try:
                cond =  np.isnan(labels)
                print(labels, cond)
                if  np.isnan(labels) == True:
                    filt_index = n_maximos.index[n_maximos[col].isnull()].tolist()
                else:
                    filt_index = n_maximos.index[n_maximos[col] == labels].tolist()
            except:
                print(labels, type(labels))
                filt_index = n_maximos.index[n_maximos[col] == labels].tolist()
            if len(filt_index) != 0:
                if cond == True:
                    propension_val.loc[filt_index, col] = np.nan
                else:
                    propension_val.loc[filt_index, col] = df_wide_values.loc[n_maximos.index[n_maximos[col] == labels], labels].values
    propension_val.columns = [f'{column_name}_{i}' for i in range(1,n_maximos.shape[1]+1,1)]
    return propension_val

### Tercer pipeline
def reshape_dataframe(df,params):
    """
    Tomar los pronosticos individuales por modelo, los ordena por id y producto segun la optimizacion del de mayor propension y los entrega en el formato de la linea de negocio.
    
    Parameters
    ----------
    df:
        DataFrame con los pronosticos de cada producto de manera indifivual concatenado por fila
    
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    pd.DataFrame del modelo 360 optimizado
    """
    # Parametros
    probs_normalizadas = params['reprocesar_probs_norm']
    ids = params['id']
    #deciles = params['deciles']
    # Pivot the dataframe
    logger.info(f"Generando la tabla dinamica..")
    display(df.groupby(['product','prob_segment']).describe()['pred_proba']*100)
    df_wide = df.pivot(index=['periodo', ids], 
                       columns='product', 
                       values=['pred_proba_normalized','pred_proba', 'prob_segment'])

    # Flatten the column names
    df_wide.columns = [f'{col[1]}_{col[0]}' for col in df_wide.columns]

    # Reset the index to make 'periodo' and 'hashvalue1' regular columns
    df_wide = df_wide.reset_index()
    # Get unique products in the order they appear in the original dataframe
    products = df['product'].unique()
    column_filt = []
    for product in products:
         column_filt.append(product+'_pred_proba')
    column_filt2 = []
    for product in products:
         column_filt2.append(product+'_prob_segment')
    column_filt3 = []
    for product in products:
         column_filt3.append(product+'_pred_proba_normalized')
    # # Create the dynamic column order
    df_wide = df_wide.set_index(ids)
    df_wide_probs = df_wide[column_filt] # campana_permanente2
    df_wide_probs.columns = products
    df_wide_propen = df_wide[column_filt2] # campana_permanente3
    df_wide_propen.columns = products
    df_wide_probs_norm = df_wide[column_filt3] # campana_permanente
    df_wide_probs_norm.columns = products
    logger.info(f"Analizando los niveles de propension duplicados")
    duplicados_por_fila = df_wide_propen.apply(lambda x: x.value_counts().max() - 1, axis=1)
    comparacion = df_wide_propen.fillna(np.nan).replace([None,np.nan,'nan', 'Muy Bajo', 'Bajo', 'Medio','Alto', 'Muy Alto'],[0,0,0,1,2,3,4,5])
    n_maximos = optimizando_propension(comparacion,products)
    df_final = pd.concat([n_maximos,duplicados_por_fila.to_frame().rename(columns={0:'duplicados'})], axis = 1)
    corregir = df_final[df_final['duplicados'] != 0]
    logger.info(f"% de Reprocesamiento: {corregir.shape[0]/df_final.shape[0]}")
    # definiendos los productos segun la prob o la prob estandarizada
    if probs_normalizadas==True:
        corregir_probs = df_wide_probs_norm.fillna(np.nan).loc[corregir.index]
    else:
        corregir_probs = df_wide_probs.fillna(np.nan).loc[corregir.index]
    
    logger.info(f"Actualizando el reprocesamiento...")
    n_maximos = optimizando_propension(corregir_probs,products)
    # corrigiendo
    df_final.loc[n_maximos.index, n_maximos.columns] = n_maximos
    df_final = df_final.drop('duplicados', axis= 1)
    probs_ord = adjust_format(df_final,df_wide_probs,'probabilidad')
    propension_ord = adjust_format(df_final,df_wide_propen,'propension')
    df_final = pd.concat([probs_ord,df_final,propension_ord], axis = 1)
    df_final = pd.concat([df_final,comparacion.sum(axis=1).to_frame().rename(columns={0:'decil_probabilidad'})], axis = 1)
    ress = backtesting.deciles_func(df_final['decil_probabilidad'], 10)
    if len(ress.unique()) != 0:
        ress = pd.cut(df_final['decil_probabilidad'], bins=10, labels=list(range(1,10+1,1)))
    logger.info(f"Ajuste de deciles: {len(ress.unique())}")
    df_final['decil_probabilidad'] = ress
    df_final.sort_values(by= 'decil_probabilidad', ascending=False, inplace = True)
    return df_final
    
# 4to pipeline
def union_frames(campana,inputs_df,params):
    """
    Tomar los pronosticos del modelo 360, le añade las variables extras y el DEFINIT en el formato deseado por la linea de negocio.
    Posteriormente guarda los resultados
    
    Parameters
    ----------
    campana:
        DataFrame con los pronosticos optimizados del modelo 360
    inputs_df:
        DataFrame con las variables extras deseadas por la linea de negocio
        
    params: Dict[str, Any]
        Diccionario de parámetros utilizados en el proceso de preparación de datos.

    Returns
    -------
    pd.DataFrame del modelo 360 optimizado con las variables extras
    """
    ids = params['id']
    ruta_save = params['ruta_save']
    logger.info(f"Unificando Modelo 360 con las variables anexos...")
    campana = campana.reset_index()
    campana2 = pd.merge(campana,inputs_df, on = ids, how = 'left')
    columns = campana2.columns.tolist()
    columns.insert(1,'DEFINIT')
    campana2 = pd.concat([campana2[ids].str[1:].to_frame().rename(columns = {ids:'DEFINIT'}),campana2],
                                    axis = 1)
    campana2 = campana2[columns]
    display(campana2.head())
    logger.info(f"Guardando archivo formato parquet: {ruta_save}")
    campana2.to_parquet(ruta_save)
    return campana2