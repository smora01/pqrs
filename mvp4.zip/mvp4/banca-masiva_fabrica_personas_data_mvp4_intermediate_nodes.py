"""
Nodos de la capa intermediate
"""
from typing import Dict, List, Any, Tuple

import pandas as pd
import polars as pl
import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# 1. Filtro de segmento
def filter_data_segment_pd(
    df: pd.DataFrame, 
    params: Dict[str, Any],
) -> pd.DataFrame:
    """
    Filtra un DataFrame basado en múltiples valores de un segmento específico de datos y reasigna estos valores a un nombre único.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame de pandas que contiene los datos a filtrar.
    params: Dict[str, Any] 
        Diccionario de parámetros intermediate.

    Returns
    -------
    pd.DataFrame: DataFrame filtrado y modificado con los valores reasignados.
    """
    # Registra un mensaje de información indicando el inicio del filtrado
    logger.info("Iniciando el filtrado de datos por segmento y reasignación de valores...")

    # Extrae los nombres de las columnas, valores y el nombre a reasignar desde el diccionario de parámetros
    segment_col = params['filter_segment']['column']
    segment_values = params['filter_segment']['value'].split(', ')
    new_name = params['filter_segment']['name']

    # Filtra el DataFrame basado en los valores proporcionados
    filtered_df = df[df[segment_col].isin(segment_values)]
    
    # Reasigna los valores filtrados al nuevo nombre
    filtered_df[segment_col] = new_name
    
    # Registra un mensaje de información indicando el resultado del filtrado y reasignación
    logger.info(f"Filtrado y reasignación completados. {len(filtered_df)} registros retenidos con el nuevo nombre '{new_name}'.")

    # Retorna el DataFrame filtrado y modificado
    return filtered_df

    
# 2. Filtro de producto 
def filter_data_prod_pd(
    df: pd.DataFrame, 
    params: Dict[str, Any],
) -> pd.DataFrame:
    """
    Elimina columnas específicas de un DataFrame basadas en una lista de variables proporcionada en los parámetros,
    excluyendo la primera variable, que se considera la variable objetivo.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame de pandas que contiene los datos a procesar.
    params: Dict[str, Any] 
        Diccionario de parámetros que contiene la lista de columnas a eliminar.

    Returns
    -------
    pd.DataFrame: DataFrame con las columnas especificadas eliminadas.
    """
    # Registra un mensaje de información indicando el inicio del proceso de eliminación de columnas
    logger.info(f"Iniciando la eliminación de columnas de datos de producto {df.shape} ...")

    # Extrae la lista de columnas a eliminar desde el diccionario de parámetros, excluyendo el primer elemento
    columns_to_drop = params['filter_product'][1:]

    # Obtiene la variable objetivo, que es el primer elemento de la lista
    target_variable = params['target']

    # Elimina las columnas especificadas
    df_filtered = df.drop(columns=columns_to_drop, errors='ignore')
    
    # Registra un mensaje de información indicando el resultado de la eliminación
    logger.info(f"Eliminación de columnas completada. Variable objetivo: {target_variable} y el dataframe resultante es {df_filtered.shape}")

    # Retorna el DataFrame con las columnas eliminadas
    return df_filtered
