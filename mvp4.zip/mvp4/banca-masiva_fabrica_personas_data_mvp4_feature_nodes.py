"""
Nodos de la capa feature
"""
from typing import Dict, Any , Tuple ,List
import pandas as pd
import logging
import re
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer, KNNImputer
from xgboost import XGBRegressor
from sklearn.experimental import enable_iterative_imputer  # Necesario para habilitar el IterativeImputer
# from sklearn.impute import IterativeImputer

# Configuración básica del logger
logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# 0. Función para calcular nuevas variables
def calculate_new_variables_pd(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calcula nuevas variables basadas en la suma de saldos de activos y pasivos,
    así como los deltas entre diferentes periodos para columnas específicas.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame con las columnas necesarias para calcular las nuevas variables.

    Returns
    -------
    pd.DataFrame
        DataFrame con las nuevas variables calculadas.
    """
    logger.info("Calculando nuevas variables de saldos y deltas...")

    df['sum_saldo_activos'] = (
        df['ah_sum_saldo_promedio'] +
        df['cc_sum_saldo_promedio'] +
        df['cdt_sum_monto_apertura'] +   
        df['cdt_sum_valor_interes']
    )
    df['sum_saldo_pasivos'] = (
        df['tc_sum_saldo_mean_2'] +
        df['ld_sum_saldo_promedio'] +
        df['lib_saldo_promedio'] +
        df['sus_saldo_promedio'] +
        df['veh_sum_saldo_promedio'] +
        df['viv_sum_saldo_promedio']
    )
    df['delta_ah_sum_monto_trx_credito'] = df['ah_sum_monto_trx_credito_mean_2'] - df['ah_sum_monto_trx_credito_mean_6']
    df['delta_ah_sum_monto_trx_debito'] = df['ah_sum_monto_trx_debito_mean_2'] - df['ah_sum_monto_trx_debito_mean_6']
    df['delta_tc_sum_facturacion_total'] = df['tc_sum_facturacion_total_valor_mean_2'] - df['tc_sum_facturacion_total_valor_mean_6']

    df['num_activos_prev']= df['ah_cant_prev']+df['cc_cant_prev']+df['cdt_cant_prev']

    df['num_pasivos_prev']= df['cs_cant_prev']+df['fac_cant_prev']+df['fid_cant_prev']+df['lib_cant_prev']+df['sus_cant_prev']+df['veh_cant_prev']+df['viv_cant_prev'] #+df['ld_cant_prev']

    df['num_prod_activos']= df['ah_cant']+df['cc_cant']+df['cdt_cant']

    df['num_prod_pasivos']= df['cs_cant']+df['fac_cant']+df['fid_cant']+df['lib_cant']+df['sus_cant']+df['veh_cant']+df['viv_cant'] #+df['ld_cant']
    
    logger.info(f"Cálculo de nuevas variables completado.{df.shape}")
    return df

# 1 Agregar regiones segun el departamento

def homologate_region(df: pd.DataFrame,parametros: Dict) -> pd.DataFrame:
    """
    Homologa las regiones en el DataFrame en base al diccionario de homologaciones.

    Args:
        df (pd.DataFrame): DataFrame que contiene la columna de departamentos a homologar.
        departamento_col (str): Nombre de la columna que contiene los departamentos.

    Returns:
        pd.DataFrame: DataFrame con la nueva columna de regiones homologadas.
    """
    
    # Diccionario de homologación de departamentos a regiones
    homologations = {
        "amazonas": "Region_Amazonica",
        "antioquia": "Region_Andina",
        "arauca": "Region_Orinoquia",
        "archipielago_de_san_andres_providencia_y": "Region_Caribe",
        "atlantico": "Region_Caribe",
        "bogota_d_c": "Region_Central",
        "bolivar": "Region_Caribe",
        "boyaca": "Region_Andina",
        "caldas": "Region_Andina",
        "caqueta": "Region_Amazonica",
        "casanare": "Region_Orinoquia",
        "cauca": "Region_Pacifica",
        "cesar": "Region_Caribe",
        "choco": "Region_Pacifica",
        "cordoba": "Region_Caribe",
        "cundinamarca": "Region_Andina",
        "guainia": "Region_Amazonica",
        "guaviare": "Region_Amazonica",
        "huila": "Region_Andina",
        "la_guajira": "Region_Caribe",
        "magdalena": "Region_Caribe",
        "meta": "Region_Orinoquia",
        "narino": "Region_Pacifica",
        "norte_de_santander": "Region_Andina",
        "putumayo": "Region_Amazonica",
        "quindio": "Region_Andina",
        "risaralda": "Region_Andina",
        "santander": "Region_Andina",
        "sucre": "Region_Caribe",
        "tolima": "Region_Andina",
        "valle_del_cauca": "Region_Pacifica",
        "vaupes": "Region_Amazonica",
        "vichada": "Region_Orinoquia"
    }
    
    departamento_col= parametros['departamento_col']
    # Normalizar los nombres de los departamentos (ej. a minúsculas y sin espacios)
    df[departamento_col] = df[departamento_col].str.lower().str.replace(r'\s+', '_', regex=True)
    
    # Mapear los departamentos a regiones usando el diccionario de homologaciones
    df["region"] = df[departamento_col].map(homologations).fillna("Other_Region")
    logger.info(f"Tamaño de mi df: {df.shape}")
    return df

# 2 Eliminar columnas de apertura de productos 
def eliminar_columnas(df: pd.DataFrame, parametros: List[str]) -> pd.DataFrame:
    """
    Elimina las columnas especificadas en cols_to_drop del DataFrame.
    
    Parameters
    ----------
    df : pd.DataFrame
    DataFrame que contiene los datos de entrada.
    cols_to_drop : List[str]
    Lista de columnas que se desea eliminar.
    
    Returns
    -------
    pd.DataFrame
    DataFrame sin las columnas especificadas.
    """

    cols_to_drop=parametros['cols_to_drop']
    # Verificar si las columnas a eliminar existen en el DataFrame antes de intentar eliminarlas
    columnas_existentes_a_eliminar = [col for col in cols_to_drop if col in df.columns]
    # Eliminar las columnas que existen en el DataFrame
    df.drop(columns=columnas_existentes_a_eliminar, inplace=True)
    logger.info(f"Tamaño de mi df: {df.shape}")
    return df

# 3. Función para procesar la importancia de características
def preprocesar_feature_df(df: pd.DataFrame, params: Dict[str, Any]) -> pd.DataFrame:
    """
    Preprocesa el DataFrame para codificar variables categóricas y realizar imputación de valores faltantes.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame con las características originales.
    params : Dict[str, Any]
        Diccionario de parámetros que incluye la columna a conservar.

    Returns
    -------
    pd.DataFrame
        DataFrame preprocesado con variables categóricas codificadas y valores faltantes imputados.
    """
    logger.info("Iniciando el preprocesamiento del DataFrame...")

    # Identificar columnas categóricas
    categorical_columns = df.select_dtypes(include=['object']).columns.tolist()
    target = params['target']
    
    # Codificación de columnas categóricas
    df_encoded = df.copy()
    label_encoders = {}
    for col in categorical_columns:
        le = LabelEncoder()
        df_encoded[col] = le.fit_transform(df_encoded[col].astype(str))
        label_encoders[col] = le

    # Imputar valores faltantes
    for col in df_encoded.columns:
        if df_encoded[col].dtype == 'object':
            df_encoded[col].fillna(df_encoded[col].mode()[0], inplace=True)
        else:
            df_encoded[col].fillna(df_encoded[col].median(), inplace=True)

    # Convertir todos los datos a numéricos
    df_encoded = df_encoded.apply(pd.to_numeric, errors='coerce')

    return df_encoded

# 4 separar características

def separar_características(df: pd.DataFrame, params: Dict[str, Any]) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Separa las características y la variable objetivo del DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame preprocesado.
    params : Dict[str, Any]
        Diccionario de parámetros que incluye la columna a conservar.

    Returns
    -------
    Tuple[pd.DataFrame, pd.Series]
        DataFrame con características y Serie con la variable objetivo.
    """
    logger.info("Separando características y la variable objetivo...")
    
    # Verifica que params['target'] sea un string
    target = params.get('target')
    
    if not isinstance(target, str):
        logger.error(f"El valor de 'target' no es una cadena: {target}")
        raise TypeError("El valor de 'target' debe ser una cadena que representa el nombre de la columna.")

    logger.info(f"Columna a conservar: {target}")
    
    X = df.drop(columns=[target])
    y = df[target]
    
    return X, y

# 5 Calcular importancia 

def calcular_importancia(X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
    """
    Calcula la importancia de las características utilizando un modelo de XGBoost.

    Parameters
    ----------
    X : pd.DataFrame
        DataFrame con las características.
    y : pd.Series
        Serie con la variable objetivo.

    Returns
    -------
    pd.DataFrame
        DataFrame con la importancia de las características ordenadas.
    """
    logger.info("Calculando la importancia de las características usando XGBoost...")

    # Definir el modelo XGBoost
    regressor = XGBRegressor(max_depth=5, random_state=42, n_estimators=60)
    
    # Ajustar el modelo a los datos
    regressor.fit(X, y)
    
    # Obtener la importancia de las características
    importances = regressor.feature_importances_
    feature_names = X.columns
    importance_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
    
    # Ordenar las características por importancia
    importance_df = importance_df.sort_values(by='Importance', ascending=False)
    
    return importance_df

# 6 Seleccionar características

def seleccionar_características(importance_df: pd.DataFrame, df: pd.DataFrame, params: Dict[str, Any]) -> pd.DataFrame:
    """
    Orden las características segun su importancia y añade las caracteristicas requeridas en el modelo.

    Parameters
    ----------
    importance_df : pd.DataFrame
        DataFrame con la importancia de las características.
    df : pd.DataFrame
        DataFrame original con las características.
    params : Dict[str, Any]
        Diccionario de parámetros que incluye las características requeridas.

    Returns
    -------
    pd.DataFrame
        DataFrame con la importancia de las características seleccionadas.
    """
    logger.info("Seleccionando las 25 características más importantes...")

    # Asegurar que las características requeridas estén en importance_df
    required_features = params['requered_importances']['variables']
    
    required_features_in_df = [feat for feat in required_features if feat in df.columns]
    
    for feat in required_features_in_df:
        if feat not in importance_df['Feature'].values:
            importance_df = pd.concat([importance_df, pd.DataFrame({'Feature': [feat], 'Importance': [0.001]})], ignore_index=True)
    
    # Ordenar por importancia
    importance_df = importance_df.sort_values(by='Importance', ascending=False)

    logger.info(f"Se seleccionaron {len(importance_df)} características importantes.")
    return importance_df



# 7. Función para filtrar columnas en un DataFrame
def filtrar_columnas_df(segmented_df: pd.DataFrame, 
                        importance_df: pd.DataFrame, 
                        params: Dict[str, Any]) -> pd.DataFrame:
    """
    Filtra las columnas de un DataFrame basándose en la importancia de las características
    y conserva una columna adicional especificada, eliminando columnas no deseadas si están presentes.

    Parameters
    ----------
    segmented_df : pd.DataFrame
        DataFrame que contiene el segmento a filtrar.
    importance_df : pd.DataFrame
        DataFrame con la importancia de las características.
    params : Dict[str, Any]
        Diccionario de parámetros que incluye la columna a conservar.

    Returns
    -------
    pd.DataFrame
        DataFrame filtrado con las columnas seleccionadas.
    """
    logger.info("Filtrando columnas del DataFrame basado en la importancia de características...")

    target = params['target']
    metodo = params['requered_importances']['ignore_importance']
    if metodo==False:
        n = 25
        logger.info(f"Tomando las  {n} variables de mayor importancia")
        selected_columns = importance_df.head(n)['Feature'].tolist()
    else:
        logger.info(f"Ignorando las variables de mayor importancia y escogiendo las requeridas")
        selected_columns1 =  params['requered_importances']['variables']
        selected_columns1 = list(set(selected_columns1)) # unicos
        selected_columns = []
        for col in selected_columns1:
            if col in importance_df['Feature']:
                selected_columns.append(col)
            else:
                logger.info(f"La variable {col} no esta parametrizada en los feature importance... Puede que este mal escrita en los parameters")
    
    # Asegurar que la columna a conservar esté en la lista de columnas seleccionadas
    if target not in selected_columns:
        selected_columns.append(target)
    
    # Lista de columnas no deseadas que queremos eliminar si están presentes
    columns_to_remove = ['periodo', 'tc_target_ap_shift__1']
    
    # Eliminar columnas no deseadas de la lista de columnas seleccionadas
    selected_columns = [col for col in selected_columns if col not in columns_to_remove]
    logger.info(f"Columnas eliminadas: {columns_to_remove}")
    
    filtered_df = segmented_df[selected_columns]
    logger.info(f"Filtrado completado. Columnas seleccionadas: {selected_columns}")
    
    return filtered_df
