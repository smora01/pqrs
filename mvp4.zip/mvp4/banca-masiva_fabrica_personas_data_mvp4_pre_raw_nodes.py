"""
This is a boilerplate pipeline 'pre_raw'
generated using Kedro 0.18.14
"""

from typing import Dict, List, Any, Tuple

import pandas as pd
import polars as pl
import numpy as np
import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

#1. Leer la ventana de entrenamiento y filtrar variables.
def concat_dataframes_pl_pd(
    df1: pl.DataFrame,
    df2: pl.DataFrame,
    df3: pl.DataFrame,
    df4: pl.DataFrame,
    df5: pl.DataFrame,
    df6: pl.DataFrame,
    df7: pl.DataFrame,
    params: Dict[str, Any]
) -> pd.DataFrame:
    logger.info("Iniciando el proceso de filtrado y concatenación de DataFrames...")

    variables = params['vars']
    
    def convertir_a_float64(df: pl.DataFrame, cols: list) -> pl.DataFrame:
        numeric_cols = [col for col in cols if df[col].dtype in [pl.Float64, pl.Int64, pl.Int32, pl.Float32]]
        return df.select(cols).with_columns([pl.col(col).cast(pl.Float64) for col in numeric_cols])

    df1 = convertir_a_float64(df1, variables)
    df2 = convertir_a_float64(df2, variables)
    df3 = convertir_a_float64(df3, variables)
    df4 = convertir_a_float64(df4, variables)
    df5 = convertir_a_float64(df5, variables)
    df6 = convertir_a_float64(df6, variables)
    df7 = convertir_a_float64(df7, variables)

    df_list = [df1, df2, df3, df4, df5, df6, df7]

    df_final = pl.concat(df_list, how='vertical')

    logger.info(f"DataFrame concatenado: {df_final.shape[0]} registros y {df_final.shape[1]} columnas.")

    df_final_pd = df_final.to_pandas()

    if df_final_pd is None or df_final_pd.empty:
        logger.error("El DataFrame final es None o está vacío.")
        return None

    logger.info("Proceso de concatenación completado y convertido a DataFrame de pandas.")
    return df_final_pd