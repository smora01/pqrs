"""
Nodos de la capa raw
"""
from typing import Dict, List, Any, Tuple

import re
import pandas as pd
import polars as pl
import numpy as np
import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

#1. Leer la ventana de entrenamiento y filtrar variables.
def validar_columnas(df: pd.DataFrame, params: Dict[str, List[str]]) -> pd.DataFrame:

    """

    Valida que el DataFrame contenga las columnas definidas en los parámetros.
    Parameters
    ----------
    df : pd.DataFrame

        DataFrame a validar.

    params : Dict[str, List[str]]

        Diccionario que contiene la lista de columnas esperadas bajo la clave 'vars'.
    Returns

    -------

    pd.DataFrame

        El DataFrame original si todas las columnas están presentes.
    Raises

    ------
    NameError
        Si faltan columnas en el DataFrame.
    """

    # Obtener la lista de columnas esperadas

    expected_columns = params.get('vars', [])
    # filtar las columnas espereadas

    df=df[expected_columns]

    # Identificar las columnas faltantes

    missing_cols = list(set(expected_columns) - set(df.columns))

    # Si hay columnas faltantes, registrar un error y lanzar una excepción

    if len(missing_cols) > 0:

        logger.error(f"Cantidad de columnas faltantes: {len(missing_cols)}")

        logger.error(f"Columnas faltantes: {missing_cols}")

        raise NameError("La tabla no tiene las columnas necesarias para el procesamiento")

    else:

        # Si no faltan columnas, registrar un mensaje de información

        logger.info("La tabla contiene las columnas necesarias")

        return df


# 2 . minuscalas 
def convertir_a_minusculas(df, columna_excluida='hashvalue1'):
    # Convertir los nombres de las columnas a minúsculas, excepto la columna excluida
    df.columns = [col.lower() if col != columna_excluida else col for col in df.columns]
    
    # Convertir a minúsculas las columnas que sean de tipo object (string), excepto la columna excluida
    for col in df.select_dtypes(include=['object']).columns:
        if col != columna_excluida:
            # codigo viejo
            #df[col] = df[col].str.lower()
            # codigo nuevo
            try:
                prueba = df[col][~df[col].isnull()].astype(float)
                df.loc[:,col] = df.loc[:,col].astype(float)
                logger.info(f'Variable {col} es flotante')
            except:
                df.loc[:,col] = df.loc[:,col].str.lower()
    return df

# 3 Valores especiales 
def standardize_strings(df: pd.DataFrame, param_id_col: str) -> pd.DataFrame:
    """
    Estandariza los strings para columnas de texto en un DataFrame de Pandas.
    Reemplaza caracteres con tilde por sus versiones sin tilde, y otros caracteres
    especiales los reemplaza por "_".
    
    Parámetros:
    df : pd.DataFrame
        DataFrame de entrada.
    param_id_col : str
        Columna que no debe ser modificada.
    
    Retorna:
    pd.DataFrame
        DataFrame con las columnas de texto estandarizadas.
    """
    # Obtener las columnas de tipo object (string) excepto la columna id
    string_cols = df.select_dtypes(include=['object']).columns.tolist()
    if param_id_col in string_cols:
        string_cols.remove(param_id_col)

    # Diccionario de caracteres con tildes a reemplazar
    string_to_replace = {
        "á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u",
        "ý": "y", "à": "a", "è": "e", "ì": "i", "ò": "o",
        "ù": "u", "ä": "a", "ë": "e", "ï": "i", "ö": "o",
        "ü": "u", "ÿ": "y", "â": "a", "ê": "e", "î": "i",
        "ô": "o", "û": "u", "ã": "a", "õ": "o", "@": "a",
        "ñ": "n"
    }
    
    # Caracteres especiales a reemplazar por "_"
    special_chars = r"[()/*\s:.\-;<>?/,'']"

    # Función que reemplaza caracteres en un string
    def replace_special_characters(text):
        if pd.isnull(text):
            return text
        # Reemplazar caracteres con tilde por los equivalentes sin tilde
        for key, value in string_to_replace.items():
            text = text.replace(key, value)
        # Reemplazar caracteres especiales por "_"
        text = re.sub(special_chars, "_", text)
        return text

    # Aplicar los reemplazos a cada columna de tipo string
    for col in string_cols:
        df[col] = df[col].apply(replace_special_characters)

    return df


#4. definir valores nulos fill nan 
def values_to_null(df: pd.DataFrame) -> pd.DataFrame:
    # (df:pd.DataFrame, param_buro_null: List[Any]) -> pd.DataFrame:
    """
    Reemplaza valores por nulos.
    """
    df = df.fillna(np.nan)

    return df

# 5. se cambia el tipo de datos a los standard

def change_dtypes(df: pd.DataFrame, parametros: Dict[str, str]) -> pd.DataFrame:
    """
    Cambia el tipo de datos para cada columna del DataFrame según los parámetros.


    Parameters
    ----------
    df : pd.DataFrame
        DataFrame a modificar.
    param_col_types : Dict[str, str]
        Diccionario que contiene los nombres de las columnas y sus tipos esperados.


    Returns
    -------
    pd.DataFrame
        DataFrame con los tipos de datos modificados.
    """
    
    param_col_types=parametros['param_col_types']
    new_cols = []
    for col in df.columns:
        if col in param_col_types:
            expected_dtype = param_col_types[col]
            current_dtype = df[col].dtype


            # Verificar si el tipo de dato actual es diferente del tipo de dato esperado
            if current_dtype != expected_dtype:
                if df[col].isna().any() and (pd.api.types.is_integer_dtype(expected_dtype) or pd.api.types.is_bool_dtype(expected_dtype)):
                    if pd.api.types.is_integer_dtype(expected_dtype):
                        fill_value = 0  # Cambiar a un valor adecuado si necesario
                    elif pd.api.types.is_bool_dtype(expected_dtype):
                        fill_value = False  # Cambiar a un valor adecuado si necesario
                    df[col] = df[col].fillna(fill_value).astype(expected_dtype)
                else:
                    df[col] = df[col].astype(expected_dtype)
        else:
            new_cols.append(col)


    logger.warning(f"Cantidad de columnas sin usar: {len(new_cols)}")
    logger.warning(f"Columnas sin usar: {new_cols}")


    return df


#6. validar que no hay duplicados por cada periodo-id
def validate_unique_id_period_pd(
    df: pd.DataFrame, 
    params: Dict[str, Any],
) -> pd.DataFrame:
    """
    Valida que no haya duplicados por cada combinación de ID y Periodo en un DataFrame.
    Si se encuentran duplicados, informa cuántos hay por cada periodo y elimina los duplicados,
    quedándose con la última aparición de cada registro.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame que contiene las columnas de ID y Periodo a validar.
    params: Dict[str, Any] 
        Diccionario de parámetros raw.

    Returns
    -------
    pd.DataFrame: DataFrame sin duplicados, manteniendo solo la última aparición por combinación de ID y Periodo.
    """
    # Registra un mensaje de información indicando el inicio de la validación
    logger.info("Iniciando la validación de duplicados por ID y Periodo...")

    # Extrae los nombres de las columnas desde el diccionario de parámetros
    id_col = params['vars'][0]
    period_col = params['vars'][1]

    # Identifica duplicados en la combinación de ID y Periodo
    duplicates = df[df.duplicated(subset=[id_col, period_col], keep=False)]
    
    if not duplicates.empty:
        # Informa cuántos duplicados hay por cada valor de Periodo
        duplicates_count = duplicates.groupby(period_col).size()
        for period, count in duplicates_count.items():
            logger.warning(f"Periodo {period}: Se encontraron {count} duplicados.")

        # Elimina los duplicados, quedándose solo con la última aparición
        df = df.drop_duplicates(subset=[id_col, period_col], keep='last')

        logger.info("Duplicados eliminados, conservando la última aparición de cada registro.")
    else:
        # Registra un mensaje de información indicando la validación exitosa
        logger.info("Validación exitosa: No se encontraron duplicados.")
    
    # Retorna el DataFrame procesado
    return df

# #4. Crear targets
# def create_targets_pd(
#     df: pd.DataFrame, 
#     params: Dict[str, Any]
# ) -> pd.DataFrame:
#     """
#     Crea variables objetivo para aperturas de productos, agrupando por hashvalue1 y periodo.

#     Parameters
#     ----------
#     df : pandas.DataFrame
#         DataFrame que contiene los datos de entrada.
#     params: Dict[str, Any] 
#         Diccionario de parámetros que contiene la lista de variables.

#     Returns
#     -------
#     pd.DataFrame: DataFrame con las variables objetivo añadidas.
#     """
#     # Registra un mensaje de información indicando el inicio del proceso de creación de targets
#     logger.info("Iniciando la creación de variables objetivo...")

#     # Obtener el ID y el periodo
#     id_col = params['vars'][0]
#     periodo_col = params['vars'][1]

#     # Crear variables objetivo para cada producto
#     productos = ['tc', 'ld', 'cdt', 'ah', 'cc', 'fid', 'cs', 'fac', 
#                  'lib', 'sus', 'veh', 'viv', 'ord', 'otras_ord', 'finesa']
    
#     # Iterar sobre cada producto
#     for producto in productos:
#         cant_col = f"{producto}_cant"
#         cant_prev_col = f"{producto}_cant_prev"
#         target_col = f"target_{producto}_apertura"
        
#         # Crear la variable objetivo
#         df[target_col] = np.where(
#             ((df[cant_col] - df[cant_prev_col]) > 0) | 
#             (df[cant_col].notnull() & df[cant_prev_col].isnull()),
#             1, 0
#         )

#         # Registra un mensaje de información indicando que se ha creado la variable objetivo
#         logger.info(f"Variable objetivo {target_col} creada con éxito")

#     # Registra un mensaje de información indicando la finalización del proceso de creación de targets
#     logger.info("Finalizada la creación de variables objetivo")

#     return df


# 7. Modificar targets actuales
def create_targets_pd(
    df: pd.DataFrame, 
    params: Dict[str, Any]
) -> pd.DataFrame:
    """
    Crea una variable target para aperturas de tarjetas de crédito, marcando en x, x-1 y x+1 
    si existe el mismo cliente en esos periodos.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame que contiene los datos de entrada.
    params: Dict[str, Any] 
        Diccionario de parámetros que contiene las variables necesarias.

    Returns
    -------
    pd.DataFrame: DataFrame con la variable target añadida.
    """
    logger.info(f"Iniciando la creación de la variable '{params['target']}'...")

    # Obtener el ID y el periodo
    id_col = params['vars'][0]
    periodo_col = params['vars'][1]

    # Obtener la variable de apertura desde los parámetros
    variable_apertura = params['variable_apertura']
    
    # Inicializar la columna target con ceros
    df[params['target']] = 0
    
    # Crear un DataFrame temporal con las columnas relevantes
    temp_df = df[[id_col, periodo_col, variable_apertura]].copy()
    
    # Shift para periodos x-1 y x+1
    temp_df['prev_period'] = temp_df.groupby(id_col)[variable_apertura].shift(1)
    temp_df['next_period'] = temp_df.groupby(id_col)[variable_apertura].shift(-1)
    
    # Crear una máscara para identificar dónde marcar
    mask = (temp_df[variable_apertura] == 1) | (temp_df['prev_period'] == 1) | (temp_df['next_period'] == 1)
    
    # Actualizar la columna target en el DataFrame original
    df.loc[mask, params['target']] = 1

    logger.info(f"Finalizada la creación de la variable '{params['target']}'")
    return df